const UPLOAD_FOLDER_BASE_URL = "http://localhost:5000/uploads/";

const stables = { UPLOAD_FOLDER_BASE_URL };

export default stables;
